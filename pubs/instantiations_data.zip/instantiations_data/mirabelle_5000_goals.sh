#!/bin/sh
#SBATCH --job-name=mirabelle_5000_goals
#SBATCH --partition=All
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --chdir=/home/b/bartll/Masterarbeit/evaluation

SESSIONS=$(cat 50_sessions)
ISABELLE="../isabelle/bin/isabelle"
AFP="../afp/thys"
PROVERS="e vampire zipperposition"
CALLS=100
SEED=1036875125
DATE=$(date -I)

# Remove old file
rm "mirabelle/mirabelle.log"

#1: Normal run without try0
rm ~/.isabelle/mash_state
for s in $SESSIONS; do
    srun $ISABELLE mirabelle -d $AFP -A "sledgehammer[provers=$PROVERS, strict=true, try0=false]" -m $CALLS -r $SEED $s
done
mv "mirabelle/mirabelle.log" "mirabelle/$DATE.log"

#2: Run with suggest_of
rm ~/.isabelle/mash_state
for s in $SESSIONS; do
    srun $ISABELLE mirabelle -d $AFP -A "sledgehammer[provers=$PROVERS, strict=true, try0=false, suggest_of=true]" -m $CALLS -r $SEED $s
done
mv "mirabelle/mirabelle.log" "mirabelle/$DATE-suggest_of.log"
